# Fake-News Detection: Research Design & Experiment

This repository compares Multinomial Naive Bayes and Logistic Regression for classifying news articles with TF-IDF features.

## Files
- `literature_review.md` — short summaries of five relevant sources.
- `methodology.md` — research question, dataset, cleaning, features, models, metrics, and limitations.
- `experiment.ipynb` — executable experiment notebook.
- `requirements.txt` — Python dependencies.
- `data/` — place the downloaded dataset files here (the dataset is not included in this repository).

## Dataset setup
Download the ISOT Fake and Real News dataset from a reputable dataset page. The notebook expects two files named:
- `Fake.csv`
- `True.csv`

For Google Colab, upload both files when prompted by the first notebook cell. For local use, place both files in `data/` and adapt the loading cell to point to those paths. Do not commit the large dataset files unless your instructor explicitly requires it and the dataset's terms permit it.

## Run
1. Open `experiment.ipynb` in Google Colab or Jupyter.
2. Upload `Fake.csv` and `True.csv` when prompted.
3. Run every cell from top to bottom.
4. Review the actual metrics and write 5–6 sentences about findings and future improvements at the end of the notebook.
5. Save the notebook with outputs visible.

## Git workflow
Create an `experiment` branch, make incremental commits, push the branch, open a pull request into `main`, and merge it after checking the files and notebook outputs.

## Important limitation
This experiment classifies patterns in a particular dataset. It does not independently verify whether a news claim is true.
